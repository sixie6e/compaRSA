/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionLoad_Session;
    QAction *actionSave_Session;
    QAction *actionExport_Session;
    QAction *actionExit;
    QAction *actionAbout;
    QAction *actionPlot;
    QWidget *centralwidget;
    QPushButton *runButton;
    QPushButton *stopButton;
    QProgressBar *progressBar;
    QRadioButton *radioManual;
    QRadioButton *radioAuto;
    QPlainTextEdit *textEdit_logs;
    QLineEdit *setAInput;
    QLineEdit *setBInput;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *setLength;
    QMenuBar *menubar;
    QMenu *menuFile;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(423, 505);
        QPalette palette;
        QBrush brush(QColor(154, 153, 150, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(0, 255, 0, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(119, 118, 123, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(94, 92, 100, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(255, 255, 255, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Text, brush4);
        QBrush brush5(QColor(0, 0, 0, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        QBrush brush6(QColor(36, 31, 49, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        QBrush brush7(QColor(77, 77, 77, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush7);
        palette.setBrush(QPalette::Active, QPalette::Highlight, brush1);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        QBrush brush8(QColor(239, 239, 239, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush4);
        QBrush brush9(QColor(202, 202, 202, 255));
        brush9.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush9);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush8);
        QBrush brush10(QColor(48, 140, 198, 255));
        brush10.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Highlight, brush10);
        QBrush brush11(QColor(247, 247, 247, 255));
        brush11.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush11);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush5);
        QBrush brush12(QColor(190, 190, 190, 255));
        brush12.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush12);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush12);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush12);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush7);
        QBrush brush13(QColor(145, 145, 145, 255));
        brush13.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::Highlight, brush13);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush11);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush5);
        MainWindow->setPalette(palette);
        MainWindow->setAutoFillBackground(false);
        actionLoad_Session = new QAction(MainWindow);
        actionLoad_Session->setObjectName("actionLoad_Session");
        actionSave_Session = new QAction(MainWindow);
        actionSave_Session->setObjectName("actionSave_Session");
        actionExport_Session = new QAction(MainWindow);
        actionExport_Session->setObjectName("actionExport_Session");
        actionExport_Session->setCheckable(false);
        actionExit = new QAction(MainWindow);
        actionExit->setObjectName("actionExit");
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName("actionAbout");
        actionPlot = new QAction(MainWindow);
        actionPlot->setObjectName("actionPlot");
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setAutoFillBackground(false);
        runButton = new QPushButton(centralwidget);
        runButton->setObjectName("runButton");
        runButton->setGeometry(QRect(110, 190, 80, 25));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette1.setBrush(QPalette::Inactive, QPalette::Button, brush8);
        palette1.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        runButton->setPalette(palette1);
        stopButton = new QPushButton(centralwidget);
        stopButton->setObjectName("stopButton");
        stopButton->setGeometry(QRect(230, 190, 80, 25));
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette2.setBrush(QPalette::Inactive, QPalette::Button, brush8);
        palette2.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        stopButton->setPalette(palette2);
        progressBar = new QProgressBar(centralwidget);
        progressBar->setObjectName("progressBar");
        progressBar->setGeometry(QRect(27, 241, 371, 23));
        progressBar->setAutoFillBackground(false);
        progressBar->setValue(0);
        progressBar->setInvertedAppearance(false);
        radioManual = new QRadioButton(centralwidget);
        radioManual->setObjectName("radioManual");
        radioManual->setGeometry(QRect(170, 50, 96, 23));
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::WindowText, brush4);
        palette3.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette3.setBrush(QPalette::Disabled, QPalette::WindowText, brush12);
        radioManual->setPalette(palette3);
        QFont font;
        font.setPointSize(14);
        radioManual->setFont(font);
        radioAuto = new QRadioButton(centralwidget);
        radioAuto->setObjectName("radioAuto");
        radioAuto->setGeometry(QRect(170, 20, 96, 23));
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::WindowText, brush4);
        palette4.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette4.setBrush(QPalette::Disabled, QPalette::WindowText, brush12);
        radioAuto->setPalette(palette4);
        radioAuto->setFont(font);
        radioAuto->setChecked(true);
        textEdit_logs = new QPlainTextEdit(centralwidget);
        textEdit_logs->setObjectName("textEdit_logs");
        textEdit_logs->setGeometry(QRect(10, 270, 401, 141));
        setAInput = new QLineEdit(centralwidget);
        setAInput->setObjectName("setAInput");
        setAInput->setGeometry(QRect(180, 90, 113, 24));
        setBInput = new QLineEdit(centralwidget);
        setBInput->setObjectName("setBInput");
        setBInput->setGeometry(QRect(180, 120, 113, 24));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(130, 90, 41, 16));
        QPalette palette5;
        palette5.setBrush(QPalette::Active, QPalette::WindowText, brush4);
        palette5.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette5.setBrush(QPalette::Disabled, QPalette::WindowText, brush12);
        label_2->setPalette(palette5);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(130, 120, 41, 16));
        QPalette palette6;
        palette6.setBrush(QPalette::Active, QPalette::WindowText, brush4);
        palette6.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette6.setBrush(QPalette::Disabled, QPalette::WindowText, brush12);
        label_3->setPalette(palette6);
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(100, 150, 71, 20));
        QPalette palette7;
        palette7.setBrush(QPalette::Active, QPalette::WindowText, brush4);
        palette7.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette7.setBrush(QPalette::Disabled, QPalette::WindowText, brush12);
        label_4->setPalette(palette7);
        setLength = new QLineEdit(centralwidget);
        setLength->setObjectName("setLength");
        setLength->setGeometry(QRect(180, 150, 113, 24));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 423, 22));
        QPalette palette8;
        palette8.setBrush(QPalette::Active, QPalette::Window, brush1);
        QBrush brush14(QColor(0, 170, 0, 255));
        brush14.setStyle(Qt::SolidPattern);
        palette8.setBrush(QPalette::Active, QPalette::Highlight, brush14);
        palette8.setBrush(QPalette::Inactive, QPalette::Window, brush8);
        palette8.setBrush(QPalette::Inactive, QPalette::Highlight, brush10);
        palette8.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette8.setBrush(QPalette::Disabled, QPalette::Highlight, brush13);
        menubar->setPalette(palette8);
        menuFile = new QMenu(menubar);
        menuFile->setObjectName("menuFile");
        QPalette palette9;
        QBrush brush15(QColor(36, 36, 36, 255));
        brush15.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::WindowText, brush15);
        QBrush brush16(QColor(238, 238, 238, 255));
        brush16.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::Light, brush16);
        QBrush brush17(QColor(33, 33, 33, 255));
        brush17.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::ButtonText, brush17);
        QBrush brush18(QColor(0, 149, 0, 170));
        brush18.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::Highlight, brush18);
        QBrush brush19(QColor(222, 222, 222, 255));
        brush19.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::HighlightedText, brush19);
        QBrush brush20(QColor(229, 229, 229, 255));
        brush20.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::ToolTipText, brush20);
        QBrush brush21(QColor(218, 218, 218, 255));
        brush21.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Inactive, QPalette::WindowText, brush21);
        palette9.setBrush(QPalette::Inactive, QPalette::Light, brush4);
        palette9.setBrush(QPalette::Inactive, QPalette::ButtonText, brush21);
        QBrush brush22(QColor(31, 117, 204, 170));
        brush22.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Inactive, QPalette::Highlight, brush22);
        palette9.setBrush(QPalette::Inactive, QPalette::HighlightedText, brush4);
        palette9.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush21);
        QBrush brush23(QColor(164, 166, 168, 96));
        brush23.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Disabled, QPalette::WindowText, brush23);
        palette9.setBrush(QPalette::Disabled, QPalette::Light, brush16);
        palette9.setBrush(QPalette::Disabled, QPalette::ButtonText, brush23);
        palette9.setBrush(QPalette::Disabled, QPalette::Highlight, brush22);
        palette9.setBrush(QPalette::Disabled, QPalette::HighlightedText, brush4);
        palette9.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush21);
        menuFile->setPalette(palette9);
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        statusbar->setEnabled(false);
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuFile->menuAction());
        menuFile->addAction(actionLoad_Session);
        menuFile->addAction(actionSave_Session);
        menuFile->addAction(actionExport_Session);
        menuFile->addAction(actionPlot);
        menuFile->addAction(actionAbout);
        menuFile->addAction(actionExit);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionLoad_Session->setText(QCoreApplication::translate("MainWindow", "Load Session", nullptr));
        actionSave_Session->setText(QCoreApplication::translate("MainWindow", "Save Session", nullptr));
        actionExport_Session->setText(QCoreApplication::translate("MainWindow", "Export Session", nullptr));
        actionExit->setText(QCoreApplication::translate("MainWindow", "Exit", nullptr));
        actionAbout->setText(QCoreApplication::translate("MainWindow", "About", nullptr));
        actionPlot->setText(QCoreApplication::translate("MainWindow", "Plot", nullptr));
        runButton->setText(QCoreApplication::translate("MainWindow", "Run", nullptr));
        stopButton->setText(QCoreApplication::translate("MainWindow", "Stop", nullptr));
        radioManual->setText(QCoreApplication::translate("MainWindow", "Manual", nullptr));
        radioAuto->setText(QCoreApplication::translate("MainWindow", "Auto", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Set A:", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Set B:", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Set Length:", nullptr));
        menuFile->setTitle(QCoreApplication::translate("MainWindow", "File", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
